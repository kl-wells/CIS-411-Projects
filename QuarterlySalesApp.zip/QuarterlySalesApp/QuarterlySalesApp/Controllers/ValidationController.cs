﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using QuarterlySalesApp.Models;

namespace QuarterlySalesApp.Controllers
{
    public class ValidationController : Controller
    {
        private SalesContext context { get; set; }

        public ValidationController(SalesContext ctx) => context = ctx;

        public JsonResult CheckEmployee(DateTime dob, string firstname, string lastname)
        {
            var employee = new Employee
            {
                FirstName = firstname,
                LastName = lastname,
                DOB = dob
            };

            string msg = Validate.CheckEmployee(context, employee);

            if (string.IsNullOrEmpty(msg))
            {
                return Json(true);
            }
            else
            {
                return Json(msg);
            }
        }

        public JsonResult CheckManager(int managerID, string firstname, string lastname, DateTime dob)
        {
            var employee = new Employee
            {
                FirstName = firstname,
                LastName = lastname,
                DOB = dob,
                ManagerID = managerID
            };

            string msg = Validate.CheckManagerEmployee(context, employee);

            if (string.IsNullOrEmpty(msg))
            {
                return Json(true);
            }
            else
            {
                return Json(msg);
            }
        }

        public JsonResult CheckSales(int quarter, int year, int employeeID)
        {
            var sales = new Sales
            {
                Quarter = quarter,
                Year = year,
                EmployeeID = employeeID
            };

            string msg = Validate.CheckSales(context, sales);

            if (string.IsNullOrEmpty(msg))
            {
                return Json(true);
            }
            else
                return Json(msg);
        }
    }
}
