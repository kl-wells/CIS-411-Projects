﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace QuarterlySalesApp.Models
{
    public class Employee
    {
        public int EmployeeID { get; set; }

        [Required(ErrorMessage = "Please enter a First Name")]
        [StringLength(100)]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please enter a Last Name")]
        [StringLength(100)]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Please enter a date of birth")]
        [DatePast(ErrorMessage = "Birth date must be in the past.")]
        [Remote("CheckEmployee", "Validation", AdditionalFields = "FirstName, LastName")]
        [Display(Name = "Birth Date")]
        public DateTime? DOB { get; set; }

        [Required(ErrorMessage = "Please enter the date of hire")]
        [DatePast(ErrorMessage = "Hire date must be in the past.")]
        [GreaterThan(ErrorMessage = "Hire date cannot be before the company was founded in 1995")]
        [Display(Name = "Hire Date")]
        public DateTime? HireDate { get; set; }

        [GreaterThan(ErrorMessage = "Please select a manager")]
        [Remote("CheckManager", "Validation", AdditionalFields = "FirstName, LastName, DOB")]
        [Display(Name = "Manager")]
        public int ManagerID { get; set; }

        public string FullName => $"{FirstName} {LastName}";
    }
}
