﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace QuarterlySalesApp.Models
{
    public class SalesContext : DbContext
    {
        public SalesContext(DbContextOptions<SalesContext> options) : base(options) {}

        public DbSet<Employee> Employees { get; set; }

        public DbSet<Sales> Sales { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>().HasData(
                new Employee
                {
                    EmployeeID = 1,
                    FirstName = "Charlie",
                    LastName = "Brown",
                    DOB = new DateTime(1950, 10, 30),
                    HireDate = new DateTime(1995, 1, 1)
                    ManagerID = 0
                },
                new Employee
                {
                    EmployeeID = 2,
                    FirstName = "Katie",
                    LastName = "Klen",
                    DOB = new DateTime(1980, 7, 26),
                    HireDate = new DateTime(2000, 2, 10)
                    ManagerID = 1
                },
                new Employee
                {
                    EmployeeID = 3,
                    FirstName = "Caleb",
                    LastName = "Wagon",
                    DOB = new DateTime(1984, 9, 15),
                    HireDate = new DateTime(1998, 10, 23)
                    ManagerID = 0
                }
                );
        }
    }
}
