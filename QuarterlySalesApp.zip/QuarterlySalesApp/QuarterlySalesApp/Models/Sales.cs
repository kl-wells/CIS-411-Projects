﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace QuarterlySalesApp.Models
{
    public class Sales
    {
        public int SalesID { get; set; }

        [Required(ErrorMessage = "Please enter which quarter")]
        [Range(1, 4, ErrorMessage = "Quarter must be between 1 and 4")]
        public int? Quarter { get; set; }

        [Required(ErrorMessage = "Please enter a year")]
        [GreaterThan(2000, ErrorMessage = "Year cannot be before 2000")]
        public int? Year { get; set; }

        [Required(ErrorMessage = "Please enter a sales amount")]
        [GreaterThan(0.0, ErrorMessage = "Amount must be greater than 0")]
        public int? SalesAmount { get; set; }

        [GreaterThan(0, ErrorMessage = "Please select an employee")]
        [Remote("CheckSales", "Validation", AdditionalFields = "Quarter, Year")]
        [Display(Name = "Employeee")]
        public int EmployeeID { get; set; }
        public Employee Employee { get; set; }
    }
}
