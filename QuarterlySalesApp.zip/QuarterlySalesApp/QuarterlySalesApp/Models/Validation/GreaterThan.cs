﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using QuarterlySalesApp.Models;

namespace QuarterlySalesApp.Models
{
    public class GreaterThan : ValidationAttribute
    {
        //private Employee {get; set;}

        //protected override ValidationResult IsValid(object value, ValidationContext ctx)
        //{ 
        //    if(value is int)
        //    {
        //        int valueToCheck = (int)value;

        //        if (valueToCheck > 0)
        //        {
        //            return ValidationResult.Success;
        //        }
        //    }
      
        //    string msg = base.ErrorMessage ??
        //        $"{ctx.DisplayName} must be greater than 0";
        //    return new ValidationResult(msg);
        //}
        protected override ValidationResult IsValid(object value, ValidationContext ctx)
        {
            if (value is DateTime)
            {
                DateTime dateToCheck = (DateTime)value;

                if (dateToCheck > DateTime.Today)
                {
                    return ValidationResult.Success;
                }
            }

            string msg = base.ErrorMessage ??
                $"{ctx.DisplayName} must be greater than";
            return new ValidationResult(msg);
        }
}
}
