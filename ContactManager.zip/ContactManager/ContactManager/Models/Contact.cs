﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ContactManager.Models
{
    public class Contact
    {
        public int ContactID { get; set; }


        [Required(ErrorMessage = "Please enter the first name.")]
        public string Firstname { get; set; }


        [Required(ErrorMessage = "Please enter the first name.")]
        public string Lastname { get; set; }


        [Required(ErrorMessage = "Please enter the phone number.")]
        public string Phone { get; set; }


        [Required(ErrorMessage = "Please enter the email.")]
        public string Email { get; set; }

        public string Organization { get; set; }  
        public DateTime DateAdded { get; set; }   


        [Range(1, 100000000, ErrorMessage = "Please select a category.")] 
        public int CategoryID { get; set; }
        public Category Category { get; set; }


        public string Slug => Firstname?.Replace(' ', '-').ToLower()
            + '-' + Lastname?.Replace(' ', '-').ToLower();
    }
}
