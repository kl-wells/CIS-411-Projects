using System.ComponentModel.DataAnnotations;

namespace HouseCost.Models
{
    public class HouseCostModel
    {
        [Required(ErrorMessage = "Please enter the amount of the down payment.")]
        [Range(1.0, 20000.0, ErrorMessage = "Down payment must be between $1 and 20000.")]
        public decimal? DownPayment { get; set; }

        [Required(ErrorMessage = " Please enter the cost of the monthly payments.")]
        [Range(1.9, 2500.0, ErrorMessage = "Monthly cost must be between 1 and 2500.")]
        public decimal? MonthlyCost { get; set; }

        [Required(ErrorMessage = "Please enter a number of years.")]
        [Range(1, 50, ErrorMessage = "The number of years must be between 1 and 50.")]
        public int? Years { get; set; }

        public decimal? CalculateHouseCost()
        {
            int? months = Years * 12;
            decimal? totalMonthlyCost = MonthlyCost * months;
            decimal? totalCost = totalMonthlyCost + DownPayment;

            return totalCost;
        }
    }
}
