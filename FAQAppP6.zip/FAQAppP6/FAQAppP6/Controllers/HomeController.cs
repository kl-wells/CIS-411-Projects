﻿using FAQAppP6.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace FAQAppP6.Controllers
{
    public class HomeController : Controller
    {
        private FAQContext context { get; set; }

        public HomeController(FAQContext ctx)
        {
            context = ctx;
        }

        [Route("topic/{topic}/category/{category}")]
        [Route("category/{category}")]
        [Route("topic/{topic}")]
        [Route("/")]

        public IActionResult Index(string topic, string category)
        {
            ViewBag.Topics = context.Topics.OrderBy(t => t.Name).ToList();
            ViewBag.Categories = context.Categories.OrderBy(c => c.Name).ToList();
            ViewBag.SelectedTopic = topic;

            IQueryable<FAQ> faqs = context.FAQs
                .Include(f => f.Topic).Include(f => f.Category).OrderBy(f => f.Question);

            if (!string.IsNullOrEmpty(topic))
            {
                faqs = faqs.Where(f => f.TopicID == topic);
            }
            if (!string.IsNullOrEmpty(category))
            {
                faqs = faqs.Where(f => f.CategoryID == category);
            }

            return View(faqs.ToList());
        }
    }
}
