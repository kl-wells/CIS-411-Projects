﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FAQAppP6.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    CategoryID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.CategoryID);
                });

            migrationBuilder.CreateTable(
                name: "Topics",
                columns: table => new
                {
                    TopicID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Topics", x => x.TopicID);
                });

            migrationBuilder.CreateTable(
                name: "FAQs",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Question = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Answer = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TopicID = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    CategoryID = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FAQs", x => x.ID);
                    table.ForeignKey(
                        name: "FK_FAQs_Categories_CategoryID",
                        column: x => x.CategoryID,
                        principalTable: "Categories",
                        principalColumn: "CategoryID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_FAQs_Topics_TopicID",
                        column: x => x.TopicID,
                        principalTable: "Topics",
                        principalColumn: "TopicID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryID", "Name" },
                values: new object[,]
                {
                    { "gnl", "General" },
                    { "snds", "Sounds" }
                });

            migrationBuilder.InsertData(
                table: "Topics",
                columns: new[] { "TopicID", "Name" },
                values: new object[,]
                {
                    { "farm", "Farm" },
                    { "wild", "Wild" }
                });

            migrationBuilder.InsertData(
                table: "FAQs",
                columns: new[] { "ID", "Answer", "CategoryID", "Question", "TopicID" },
                values: new object[,]
                {
                    { 1, "Pig", "snds", "What animal says oink?", "farm" },
                    { 4, "The little dog laughed to see such fun, And the dish ran away with the spoon", "gnl", "What happened when the cow jumped over the moon?", "farm" },
                    { 2, "If it's black, attack. If it's brown, lay down. If it's white, good night.", "gnl", "What are the rules for bears?", "wild" },
                    { 3, "Ring-ding-ding-ding-dingeringeding! Wa-pa-pa-pa-pa-pa-pow! Hatee-hatee-hatee-ho!", "snds", "What does the fox say?", "wild" },
                    { 5, "A rocker spaniel!!", "gnl", "What do you get when you cross a hammock and a dog?", "wild" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_FAQs_CategoryID",
                table: "FAQs",
                column: "CategoryID");

            migrationBuilder.CreateIndex(
                name: "IX_FAQs_TopicID",
                table: "FAQs",
                column: "TopicID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FAQs");

            migrationBuilder.DropTable(
                name: "Categories");

            migrationBuilder.DropTable(
                name: "Topics");
        }
    }
}
