﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace FAQAppP6.Models
{
    public class FAQ
    {
        public string Question { get; set; }

        public string Answer { get; set; }

        public int ID { get; set; }

        public string TopicID {get; set;}

        public string CategoryID { get; set; }

        public Topic Topic { get; set; }

        public Category Category { get; set; }
    }
}
