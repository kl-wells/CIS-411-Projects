using System;
using Microsoft.EntityFrameworkCore;

namespace FAQAppP6.Models
{
    public class Topic
    {
        public string TopicID { get; set; }

        public string Name { get; set; }
    }
}
