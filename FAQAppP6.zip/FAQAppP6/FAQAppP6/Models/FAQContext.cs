﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace FAQAppP6.Models
{
    public class FAQContext : DbContext
    {
        public FAQContext(DbContextOptions<FAQContext> options) : base(options)
        { }

        public DbSet<FAQ> FAQs { get; set; }

        public DbSet<Category> Categories { get; set; }

        public DbSet<Topic> Topics { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Topic>().HasData(
                new Topic { TopicID = "farm", Name = "Farm"},
                new Topic { TopicID = "wild", Name = "Wild"}
                );

            modelBuilder.Entity<Category>().HasData(
                new Category { CategoryID = "gnl", Name = "General" },
                new Category { CategoryID = "snds", Name = "Sounds" }
                );

            modelBuilder.Entity<FAQ>().HasData(
                new FAQ
                {
                    ID = 1,
                    Question = "What animal says oink?",
                    Answer = "Pig",
                    TopicID = "farm",
                    CategoryID = "snds"
                },
                new FAQ
                {
                    ID = 2,
                    Question = "What are the rules for bears?",
                    Answer = "If it's black, attack. If it's brown, lay down. If it's white, good night.",
                    TopicID = "wild",
                    CategoryID = "gnl"
                },
                new FAQ
                {
                    ID = 3,
                    Question = "What does the fox say?",
                    Answer = "Ring-ding-ding-ding-dingeringeding! Wa-pa-pa-pa-pa-pa-pow! Hatee-hatee-hatee-ho!",
                    TopicID = "wild",
                    CategoryID = "snds"
                },
                new FAQ
                {
                    ID = 4,
                    Question = "What happened when the cow jumped over the moon?",
                    Answer = "The little dog laughed to see such fun, And the dish ran away with the spoon",
                    TopicID = "farm",
                    CategoryID = "gnl"
                },
                new FAQ
                {
                    ID = 5,
                    Question = "What do you get when you cross a hammock and a dog?",
                    Answer = "A rocker spaniel!!",
                    TopicID = "wild",
                    CategoryID = "gnl"
                }
                ) ;
        }
    }
}
